function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5mf7b8HUF3g":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

